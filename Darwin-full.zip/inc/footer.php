<footer>
	  	<div class="row">
		  	<div class="container">
				<ul class="flex left">
					<li><img src="img/iso.png" alt="Darwin Tortugas"></li>
					
				</ul>
			
				<ul class="flex right">
					<li><a href="mailTo:tortugas@estudiodarwin.com.ar?subject=DESDE%20SITIO%20WEB"><b>tortugas@estudiodarwin.com.ar</b> &nbsp </a><p class="linea">|&nbsp </p><p>  +54 11 6695 8789</p></li>
					<li><a href="https://www.instagram.com/darwin.tortugas/" target="_blank"><i class="fab fa-instagram"></i></a></li>
					<li class="safari_only"><a href="https://www.facebook.com/Darwin-Tortugas-333188340810073/" target="_blank"><i class="fab fa-facebook-f"></i> </a></li>
				</ul>
			</div>
		</div>
	</footer>
