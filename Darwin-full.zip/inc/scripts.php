	<script type="text/javascript" src="js/JQuery.min.js"></script>
	<script type="text/javascript" src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="OwlCarousel2-2.3.4/dist/owl.carousel.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.6/jquery.fancybox.min.js"></script>	  	
	<script type="text/javascript" src="js/slider.js"></script>
	<script type="text/javascript" src="js/validarFormulario.js"></script>
	<script type="text/javascript" src="js/scrollFunctions.js"></script>
	<script type="text/javascript" src="js/links.js"></script>
	<script type="text/javascript" src="js/mostrarXsMenu.js"></script>
	<script type="text/javascript" src="js/scrollSpy.js"></script>