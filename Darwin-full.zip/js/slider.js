 $('#owl-1').owlCarousel({
    loop:true,
    margin:0,
    autoplay:true,
    autoplayTimeout:4000,
    nav:false,
    dots:true,
    items:1,
    responsive:{
        0:{
            items:1
        },
        1200:{
            items:1
        }
    }
});



  $('#owl-2').owlCarousel({
    loop:true,
    margin:50,
    autoplay:true,
    autoplayTimeout:2000,
    nav:false,
    dots:false,
    items:3,
    responsive:{
        0:{
            items:2
        },
        850:{
            items:2
        },
        1200:{
            items:3
        }
    }
});


  $('#owl-3').owlCarousel({
    loop:true,
    margin:300,
    autoplay:false,
    autoplayTimeout:4000,
    nav:false,
    dots:true,
    items:1,
    responsive:{
        0:{
            items:1
        },
        1200:{
            items:1
        }
    }
});


    $('#owl-3-xs').owlCarousel({
    loop:true,
    margin:300,
    autoplay:false,
    autoplayTimeout:4000,
    nav:false,
    dots:true,
    items:1,
    responsive:{
        0:{
            items:1
        },
        1200:{
            items:1
        }
    }
});


   $('#owl-4').owlCarousel({
    loop:true,
    margin:0,
    autoplay:false,
    autoplayTimeout:4000,
    nav:false,
    dots:true,
    items:1,
    responsive:{
        0:{
            items:1
        },
        1200:{
            items:1
        }
    }
});




 $('#owl-5').owlCarousel({
    loop:true,
    margin:0,
    autoplay:false,
    autoplayTimeout:4000,
    nav:false,
    dots:true,
    items:1,
    responsive:{
        0:{
            items:1
        },
        1200:{
            items:1
        }
    }
});



 $('#owl-6').owlCarousel({
    loop:false,
    margin:0,
    autoplay:false,
    autoplayTimeout:4000,
    nav:false,
    dots:true,
    items:1,
    responsive:{
        0:{
            items:1
        },
        1200:{
            items:1
        }
    }
});

